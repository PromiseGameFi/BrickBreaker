import React from "react";
import Board from "./Board";
import HighScoreDisplay from "../../components/HighScoreDisplay";

export default function Breakout() {
  return (
    <div>
      
      <Board />
    </div>
  );
}
