Welcome this project is the one that you see on Youtube in our Channel (EduRise - http://bit.ly/edurise_js)

Will be updating this project ReadMe Soon.

To start with this project, simply do
`yarn install`
`yarn start`
